public class FastCollinearPoints {
   public FastCollinearPoints(Point[] points)     // finds all line segments containing 4 or more points
    {}
   public           int numberOfSegments()        // the number of line segments
    {
	return 0;
    }
   public LineSegment[] segments()                // the line segments
    {
	return null;
    }
}
